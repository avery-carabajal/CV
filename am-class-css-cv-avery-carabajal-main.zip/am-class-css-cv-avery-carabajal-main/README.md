# CSS Resume Assignment

In this assignment, you will style a resume website using CSS. 

---

## Provided Files

- `style.css`: a template css file linked in index.html and contact.html 
- `index.html`: a template shell with css file linked
- `contact.html`: a template shell with css file linked

---
## Part 1: Project Setup

- Copy the contents of your completed `index.html` from the html assignment into the provided `index.html` template. (Keep the link to style.css.)
- Copy the contents of your completed `contact.html` from the html assignment into the provided `contact.html` template file. (Keep the link to style.css.)
- Copy the images from your completed html project to the images folder

## Part 2: Create!

Style your cv following these [step-by-step instructions](https://docs.google.com/document/d/1_Zpam8eycWh1wazH-_V9HGNCaHtEF6mf9KnPqqevdew/edit?usp=sharing). (20 pts)

### Part 3: Testing locally

After you have completed the style.css file.  You may run the test scripts locally by:

1. Install the tools by running:

   `npm install`

2. Run the test scripts:
   
   `npm test`

3. Repeat `npm test` until all tests are passed.

### Part 4: Publish your cv on your personal GitHub pages

1. **Publish your CV on GitHub pages **

You are to publish your CV to your own GitHub pages site. This is **NOT** your classroom repo created in our CSCI4300-Web-Programming organization. [instructions](https://docs.google.com/document/d/1_Zpam8eycWh1wazH-_V9HGNCaHtEF6mf9KnPqqevdew/edit?usp=sharing) for publishing on GitHub are linked.

2. **Provide the link on the class Google sheet** 

The link to the Google sheet is provided in the instructions sheet linked above.

### Part 5: Submit your assignment - git push
1. commit 
  commit your changes with appropriate commit message
2. submit - **git push**
  submit your cv - `git push` 


